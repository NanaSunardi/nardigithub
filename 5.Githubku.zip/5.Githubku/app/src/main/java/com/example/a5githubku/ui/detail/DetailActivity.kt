package com.example.a5githubku.ui.detail

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.ToggleButton
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import coil.load
import coil.transform.CircleCropTransformation
import com.dicoding.a5githubku.ui.SectionPagerAdapter
import com.example.a5githubku.R
import com.example.a5githubku.data.database.FavoriteDatabase
import com.example.a5githubku.data.database.FavoriteUser
import com.example.a5githubku.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {
    companion object{
        const val EXTRA_USERNAME = "extra_username"
//        const val EXTRA_ID = "extra_id"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_1,
            R.string.tab_2
        )
    }

    private lateinit var binding: ActivityDetailBinding
    private lateinit var viewModel: DetailViewModel

///*************    TES  ************/
//    private lateinit var username: TextView
//    private lateinit var avatarUrl: TextView
//    private lateinit var fab: ToggleButton
//    private lateinit var database: FavoriteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

///*************    TES  ************/
//        username = findViewById(R.id.tvItem)
//        avatarUrl = findViewById(R.id.img_item_photo)
//        fab = findViewById(R.id.toggle_favorite)
//        database = FavoriteDatabase.getInstance(applicationContext)
//        fab.setOnClickListener {
//            database.favoriteUserDao().insertAll(
//                FavoriteUser(
//                    null,
//                    username.text.toString(),
//                    avatarUrl.text.toString(),
//                )
//            )
//            finish()
//        }

        //Utk list followers & following
        val username = intent.getStringExtra(EXTRA_USERNAME)
        val bundle = Bundle()
        bundle.putString(EXTRA_USERNAME, username)
//        val id = intent.getIntExtra(EXTRA_ID, 0)

        // Utk Viewpager
        val sectionPagerAdapter = SectionPagerAdapter(this, username.toString())  // untuk menghubungkan SectionsPagerAdapter dengan ViewPager2
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->   // Dengan menerapkan TabLayoutMediator, maka Fragment yang tampil pada ViewPager2 akan sesuai dengan posisi yang dipilih pada tab
            tab.text = resources.getString(TAB_TITLES[position]) // Menentukan judul dari masing-masing Tab dengan menggunakan TAB_TITLE yang diambil sesuai dengan urutan posisinya
        }.attach()

        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(DetailViewModel::class.java)
        viewModel.isLoading.observe(this){
            showLoading(it)
        }
        viewModel.userDetail(username.toString())
        viewModel._items.observe(this) {
            if (it != null) {
                binding.apply {
                    tvName.text = it.name
                    tvUsername.text = it.login
                    tvFollowers.text = "${it.followers} Followers"
                    tvFollowing.text = "${it.following} Following"
                    binding.ivProfile.load(it.avatar_url) {
                        transformations(CircleCropTransformation())
                    }
                }
            }
        }


    }
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}