package com.example.a5githubku.data.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

//@Entity
//@Parcelize
//data class FavoriteUser(
//    @PrimaryKey(autoGenerate = false)
//    var username: String = "",
//    var avatarUrl: String? = null,
//):Parcelable

@Entity(tableName = "favorite_user")
data class FavoriteUser(
    val login: String,
    @PrimaryKey
    val id: Int,
): Serializable

//@Entity
//data class FavoriteUser(
//    @PrimaryKey(autoGenerate = true) var uid: Int? = null,
//    @ColumnInfo(name = "username") var username: String,
//    @ColumnInfo(name = "avatarUrl") var avatarUrl : String?,
//)