package com.example.a5githubku.ui.main

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.a5githubku.data.response.ItemsItem
import com.dicoding.a5githubku.ui.SearchViewModel
import com.dicoding.a5githubku.ui.UserAdapter
import com.example.a5githubku.databinding.ActivityMainBinding
import com.example.a5githubku.ui.detail.DetailActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: SearchViewModel

///**********   TES   ***********/
//    private lateinit var recyclerView: RecyclerView
//    private lateinit var fab: FloatingActionButton
//    private var list = mutableListOf<FavoriteUser>()
//    private lateinit var adapter: FavoriteUserAdapter
//    private lateinit var database: FavoriteDatabase

    // Utk masuk ke DetailActivity
    private fun setUserData(userData : List<ItemsItem>){
        val adapter = UserAdapter{ user ->
            val intent = Intent(this@MainActivity, DetailActivity::class.java)
            intent.putExtra(DetailActivity.EXTRA_USERNAME, user.login)
//            intent.putExtra(DetailActivity.EXTRA_ID, user.id)
            startActivity(intent)
        }
        adapter.submitList(userData)
        binding.rvListUsers.adapter = adapter
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

///**********   TES   ***********/
//        recyclerView = findViewById(R.id.rv_list_users)
//        fab = findViewById(R.id.toggle_favorite)
//
//        database = FavoriteDatabase.getInstance(applicationContext)
//        adapter = FavoriteUserAdapter(list)
//
//        recyclerView.adapter = adapter
//        recyclerView.layoutManager = LinearLayoutManager(applicationContext, VERTICAL, false)
//        recyclerView.addItemDecoration(DividerItemDecoration(applicationContext, VERTICAL))

        // Utk tampilan utama
        showLoading(true)
        val mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            MainViewModel::class.java)
        mainViewModel.items.observe(this) { items ->
            setUserData(items)
            showLoading(false)
        }
        val layoutManager = LinearLayoutManager(this)
        binding.rvListUsers.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvListUsers.addItemDecoration(itemDecoration)

        // Untuk searchview
        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            SearchViewModel::class.java)
        viewModel.items.observe(this) { items ->
            setUserData(items)
            showLoading(false)
        }
        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    searchBar.setText(searchView.text)
                    searchView.hide()
                    viewModel.searchUser(searchView.text.toString())
                    showLoading(true)
                    false
                }
        }
    }

///************   TES    ****************/
//    override fun onResume() {
//        super.onResume()
//        getData()
//    }
//
//    @SuppressLint("NotifyDataSetChanged")
//    fun getData(){
//        list.clear()
//        list.addAll(database.favoriteUserDao().getAll())
//        adapter.notifyDataSetChanged()
//    }

    // Utk Progressbar
    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}