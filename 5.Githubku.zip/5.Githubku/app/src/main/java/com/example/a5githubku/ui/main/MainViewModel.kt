package com.example.a5githubku.ui.main

import android.app.Application
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.a5githubku.data.response.GithubkuResponse
import com.dicoding.a5githubku.data.response.ItemsItem
import com.dicoding.a5githubku.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel(mApplication: Application) : ViewModel() {

    private val _items = MutableLiveData<List<ItemsItem>>()
    val items: LiveData<List<ItemsItem>> = _items

    private val _isloading = MutableLiveData<Boolean>()

    companion object {
        private const val TAG = "MainViewModel"
        private const val GITHUB_ID = "sunardi"
    }

    init {
        findGithubku()
    }

    private fun findGithubku() {
        _isloading.value = true
        val client = ApiConfig.getApiService().getSearchResult(GITHUB_ID)
        client.enqueue(object : Callback<GithubkuResponse> {
            override fun onResponse(
                call: Call<GithubkuResponse>,
                response: Response<GithubkuResponse>
            ) {
                _isloading.value = false
                if (response.isSuccessful) {
                    _items.value = response.body()?.items
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<GithubkuResponse>, t: Throwable) {
                _isloading.value = false
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }
}